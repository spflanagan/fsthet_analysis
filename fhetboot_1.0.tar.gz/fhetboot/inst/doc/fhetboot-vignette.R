## ------------------------------------------------------------------------
library(fhetboot)
gfile<-system.file("extdata", "example.genepop.txt",package = 'fhetboot')
gpop<-my.read.genepop(gfile)

## ------------------------------------------------------------------------
fsts<-calc.actual.fst(gpop)
head(fsts)

#Plot the actual values to see what your distribution looks like
par(mar=c(4,4,1,1))
plot(fsts$Ht, fsts$Fst,xlab="Ht",ylab="Fst",pch=19)

## ------------------------------------------------------------------------
boot.test<-fst.boot(gpop)
str(boot.test)
head(boot.test[[3]][[1]])

## ------------------------------------------------------------------------
#plot the results
ci.list<-ci.means(boot.test[[3]])
head(ci.list)
par(mar=c(4,4,1,1))
plotting.cis(df=fsts,ci.df=ci.list,make.file=F)


## ------------------------------------------------------------------------
boot.out<-as.data.frame(t(replicate(10, fst.boot(gpop))))

## ------------------------------------------------------------------------
par(mar=c(4,4,1,1))
plotting.cis(df=fsts,boot.out=boot.out,make.file=F)
outliers<-find.outliers(fsts,boot.out=boot.out)
head(outliers)#the CI outliers


## ------------------------------------------------------------------------
boot.pvals<-p.boot(fsts,boot.out=boot.out)
head(boot.pvals)
boot.cor.pvals<-p.adjust(boot.pvals,method="BH")
boot.sig<-boot.cor.pvals[boot.cor.pvals <= 0.05]

## ------------------------------------------------------------------------
non.boot.out<-as.data.frame(t(replicate(1, fst.boot(gpop,bootstrap = FALSE))))
non.boot.pvals<-p.boot(fsts,boot.out=non.boot.out)
non.boot.cor.pvals<-p.adjust(non.boot.pvals,method="BH")
non.boot.sig<-non.boot.cor.pvals[non.boot.cor.pvals <= 0.05]
non.boot.outliers<-find.outliers(fsts,non.boot.out)
plotting.cis(fsts,non.boot.out,make.file=F,sig.list=names(non.boot.sig))

## ----eval=F--------------------------------------------------------------
#  plotting.cis(df=fsts,boot.out=boot.out,make.file=T,file.name="ExampleOutliers.png")

## ------------------------------------------------------------------------
#calculate means
boot.out.ci<-ci.means(boot.out[[3]])

#create a data.frame of confidence intervals
cis<-as.data.frame(do.call(cbind,boot.out.ci))
colnames(cis)<-c("low","upp")
cis$Ht<-as.numeric(rownames(cis))

#plot
par(mar=c(4,4,1,1))
plot(fsts$Ht, fsts$Fst,pch=19,xlab="Ht",ylab="Fst")
points(cis$Ht,cis$low,type="l",col="red")
points(cis$Ht,cis$upp,type="l",col="red")


## ------------------------------------------------------------------------
af.actual<-apply(gpop[,3:ncol(gpop)],2,calc.allele.freq)

#extract the minimum allele frequency for each locus
min.af<-unlist(lapply(af.actual,min))
par(mar=c(2,2,2,2))
hist(min.af)

